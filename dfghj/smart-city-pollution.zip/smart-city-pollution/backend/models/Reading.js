const mongoose = require('mongoose');

const ReadingSchema = new mongoose.Schema(
  {
    station: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Station',
      required: true,
    },
    pm25: { type: Number, required: true, min: 0 },
    pm10: { type: Number, required: true, min: 0 },
    co2: { type: Number, min: 0 },
    no2: { type: Number, min: 0 },
    so2: { type: Number, min: 0 },
    o3: { type: Number, min: 0 },
    temperature: { type: Number },
    humidity: { type: Number, min: 0, max: 100 },
    aqi: { type: Number, required: true },
    category: {
      type: String,
      enum: ['Good', 'Moderate', 'Poor', 'Unhealthy', 'Severe', 'Hazardous'],
      required: true,
    },
    dominantPollutant: { type: String },
    source: {
      type: String,
      enum: ['sensor', 'manual'],
      default: 'manual',
    },
    recordedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    recordedAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

ReadingSchema.index({ station: 1, recordedAt: -1 });

module.exports = mongoose.model('Reading', ReadingSchema);
