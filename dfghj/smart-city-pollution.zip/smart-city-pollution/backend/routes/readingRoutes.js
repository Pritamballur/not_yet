const express = require('express');
const { getReadingsForStation, createReading, deleteReading } = require('../controllers/readingController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.get('/station/:stationId', getReadingsForStation);
router.post('/', protect, authorize('admin'), createReading);
router.delete('/:id', protect, authorize('admin'), deleteReading);

module.exports = router;
