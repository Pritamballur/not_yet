const express = require('express');
const { getAlerts, acknowledgeAlert } = require('../controllers/alertController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.get('/', getAlerts);
router.patch('/:id/acknowledge', protect, authorize('admin'), acknowledgeAlert);

module.exports = router;
