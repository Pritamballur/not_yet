/**
 * AQI calculation utilities.
 * Uses US EPA-style piecewise linear breakpoints for PM2.5, PM10, NO2, SO2 and O3.
 * The final AQI reported is the MAX across all pollutant sub-indices (the
 * "dominant pollutant" standard used by most real-world monitoring systems).
 */

// [Clow, Chigh, Ilow, Ihigh] breakpoints per pollutant
const BREAKPOINTS = {
  pm25: [
    [0.0, 12.0, 0, 50],
    [12.1, 35.4, 51, 100],
    [35.5, 55.4, 101, 150],
    [55.5, 150.4, 151, 200],
    [150.5, 250.4, 201, 300],
    [250.5, 350.4, 301, 400],
    [350.5, 500.4, 401, 500],
  ],
  pm10: [
    [0, 54, 0, 50],
    [55, 154, 51, 100],
    [155, 254, 101, 150],
    [255, 354, 151, 200],
    [355, 424, 201, 300],
    [425, 504, 301, 400],
    [505, 604, 401, 500],
  ],
  no2: [
    [0, 53, 0, 50],
    [54, 100, 51, 100],
    [101, 360, 101, 150],
    [361, 649, 151, 200],
    [650, 1249, 201, 300],
    [1250, 1649, 301, 400],
    [1650, 2049, 401, 500],
  ],
  so2: [
    [0, 35, 0, 50],
    [36, 75, 51, 100],
    [76, 185, 101, 150],
    [186, 304, 151, 200],
    [305, 604, 201, 300],
    [605, 804, 301, 400],
    [805, 1004, 401, 500],
  ],
  o3: [
    [0, 54, 0, 50],
    [55, 70, 51, 100],
    [71, 85, 101, 150],
    [86, 105, 151, 200],
    [106, 200, 201, 300],
  ],
};

function subIndex(pollutant, concentration) {
  if (concentration === undefined || concentration === null || Number.isNaN(concentration)) {
    return null;
  }
  const table = BREAKPOINTS[pollutant];
  if (!table) return null;

  const clamped = Math.max(0, concentration);
  const row = table.find(([lo, hi]) => clamped >= lo && clamped <= hi) || table[table.length - 1];
  const [cLow, cHigh, iLow, iHigh] = row;
  const index = ((iHigh - iLow) / (cHigh - cLow)) * (clamped - cLow) + iLow;
  return Math.round(index);
}

function categorize(aqi) {
  if (aqi <= 50) return 'Good';
  if (aqi <= 100) return 'Moderate';
  if (aqi <= 150) return 'Poor';
  if (aqi <= 200) return 'Unhealthy';
  if (aqi <= 300) return 'Severe';
  return 'Hazardous';
}

/**
 * Computes overall AQI + category + dominant pollutant from raw readings.
 * @param {{pm25:number, pm10:number, no2:number, so2:number, o3:number}} readings
 */
function computeAQI(readings) {
  const subIndices = {
    pm25: subIndex('pm25', readings.pm25),
    pm10: subIndex('pm10', readings.pm10),
    no2: subIndex('no2', readings.no2),
    so2: subIndex('so2', readings.so2),
    o3: subIndex('o3', readings.o3),
  };

  let dominantPollutant = null;
  let aqi = 0;

  Object.entries(subIndices).forEach(([pollutant, value]) => {
    if (value !== null && value > aqi) {
      aqi = value;
      dominantPollutant = pollutant;
    }
  });

  return {
    aqi,
    category: categorize(aqi),
    dominantPollutant,
  };
}

module.exports = { computeAQI, categorize, subIndex };
