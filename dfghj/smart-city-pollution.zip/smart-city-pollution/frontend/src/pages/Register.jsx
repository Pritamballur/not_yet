import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', preferredZone: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await register(form);
      navigate('/', { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to create your account. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-visual">
        <div className="sidebar-brand" style={{ padding: 0 }}>
          <div className="mark" />
          <div>
            <span>AirWatch</span>
            <small>SMART CITY MONITORING</small>
          </div>
        </div>
        <div>
          <h2 style={{ fontSize: 30, lineHeight: 1.25, maxWidth: 380 }}>
            Know the air you breathe, zone by zone.
          </h2>
          <p className="text-secondary" style={{ marginTop: 14, maxWidth: 360 }}>
            Create a free citizen account to follow your neighborhood's air quality trends and
            receive pollution alerts.
          </p>
        </div>
      </div>

      <div className="auth-form-wrap">
        <div className="auth-card">
          <span className="eyebrow">Get started</span>
          <h1>Create your account</h1>
          <p className="subtitle">Free for citizens. Takes less than a minute.</p>

          {error && <div className="error-banner">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-field">
              <label htmlFor="name">Full name</label>
              <input id="name" name="name" required value={form.name} onChange={handleChange} placeholder="Jane Doe" />
            </div>
            <div className="form-field">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={form.email}
                onChange={handleChange}
                placeholder="you@example.com"
              />
            </div>
            <div className="form-field">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                required
                minLength={6}
                value={form.password}
                onChange={handleChange}
                placeholder="At least 6 characters"
              />
            </div>
            <div className="form-field">
              <label htmlFor="preferredZone">Preferred zone (optional)</label>
              <input
                id="preferredZone"
                name="preferredZone"
                value={form.preferredZone}
                onChange={handleChange}
                placeholder="e.g. Koramangala"
              />
            </div>
            <button type="submit" className="btn btn-primary btn-block" disabled={submitting}>
              {submitting ? 'Creating account…' : 'Create account'}
            </button>
          </form>

          <div className="auth-switch">
            Already have an account? <Link to="/login">Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
