import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await login(form.email, form.password);
      navigate(location.state?.from || '/', { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || 'Unable to sign in. Please check your credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-visual">
        <div className="sidebar-brand" style={{ padding: 0 }}>
          <div className="mark" />
          <div>
            <span>AirWatch</span>
            <small>SMART CITY MONITORING</small>
          </div>
        </div>
        <div>
          <h2 style={{ fontSize: 30, lineHeight: 1.25, maxWidth: 380 }}>
            Real-time air quality across every zone of the city.
          </h2>
          <p className="text-secondary" style={{ marginTop: 14, maxWidth: 360 }}>
            Track PM2.5, PM10, and gas concentrations from live monitoring stations, and get
            alerted the moment air quality turns unhealthy.
          </p>
        </div>
        <p className="text-muted mono" style={{ fontSize: 12 }}>
          Demo admin — admin@smartcity.io / Admin@123
        </p>
      </div>

      <div className="auth-form-wrap">
        <div className="auth-card">
          <span className="eyebrow">Welcome back</span>
          <h1>Sign in to your account</h1>
          <p className="subtitle">Monitor live pollution data across the city network.</p>

          {error && <div className="error-banner">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-field">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={form.email}
                onChange={handleChange}
                placeholder="you@example.com"
              />
            </div>
            <div className="form-field">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={form.password}
                onChange={handleChange}
                placeholder="••••••••"
              />
            </div>
            <button type="submit" className="btn btn-primary btn-block" disabled={submitting}>
              {submitting ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <div className="auth-switch">
            Don't have an account? <Link to="/register">Create one</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
