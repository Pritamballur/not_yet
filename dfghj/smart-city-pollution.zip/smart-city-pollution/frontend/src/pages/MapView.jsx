import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { renderToStaticMarkup } from 'react-dom/server';
import { Link } from 'react-router-dom';
import { stationApi } from '../api';
import Loader from '../components/Loader';
import { AQI_HEX, badgeClass } from '../utils/aqi';

function pinIcon(aqi, category) {
  const color = AQI_HEX[category] || AQI_HEX.Good;
  const html = renderToStaticMarkup(
    <div className="aqi-pin" style={{ background: color }}>
      <span>{Math.round(aqi)}</span>
    </div>
  );
  return L.divIcon({ html, className: '', iconSize: [30, 30], iconAnchor: [15, 28] });
}

export default function MapView() {
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await stationApi.getAll();
        setStations(data.stations);
      } catch (err) {
        setError(err.response?.data?.message || 'Could not load station locations.');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) {
    return (
      <div className="page">
        <Loader label="Plotting monitoring stations" />
      </div>
    );
  }

  const center = stations.length
    ? [stations[0].location.lat, stations[0].location.lng]
    : [12.9716, 77.5946];

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Geospatial view</span>
          <h1>City monitoring map</h1>
          <p className="subtitle">Tap a pin to see the live AQI reading for that station.</p>
        </div>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="card" style={{ padding: 0 }}>
        <div className="map-shell">
          <MapContainer center={center} zoom={12} scrollWheelZoom>
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              attribution="&copy; OpenStreetMap contributors &copy; CARTO"
            />
            {stations.map((s) => {
              const lr = s.latestReading || {};
              const hasData = typeof lr.aqi === 'number';
              return (
                <Marker
                  key={s._id}
                  position={[s.location.lat, s.location.lng]}
                  icon={pinIcon(hasData ? lr.aqi : 0, lr.category || 'Good')}
                >
                  <Popup>
                    <div style={{ fontFamily: 'sans-serif', minWidth: 160 }}>
                      <strong>{s.name}</strong>
                      <div style={{ fontSize: 12, color: '#555', margin: '4px 0' }}>
                        {s.zone} · {s.stationCode}
                      </div>
                      {hasData ? (
                        <div style={{ fontSize: 13 }}>
                          AQI <strong>{lr.aqi}</strong> — {lr.category}
                        </div>
                      ) : (
                        <div style={{ fontSize: 12 }}>No recent readings</div>
                      )}
                      <Link to={`/stations/${s._id}`} style={{ fontSize: 12 }}>
                        View details →
                      </Link>
                    </div>
                  </Popup>
                </Marker>
              );
            })}
          </MapContainer>
        </div>
      </div>

      <div className="section-title" style={{ marginTop: 28 }}>
        Legend
      </div>
      <div className="tag-select">
        {['Good', 'Moderate', 'Poor', 'Unhealthy', 'Severe', 'Hazardous'].map((cat) => (
          <span key={cat} className={badgeClass(cat)}>
            <span className="dot" />
            {cat}
          </span>
        ))}
      </div>
    </div>
  );
}
