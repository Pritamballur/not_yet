import { useEffect, useMemo, useState } from 'react';
import { stationApi, dashboardApi } from '../api';
import StationCard from '../components/StationCard';
import AqiGauge from '../components/AqiGauge';
import Loader from '../components/Loader';
import { AQI_ADVICE } from '../utils/aqi';

export default function Dashboard() {
  const [stations, setStations] = useState([]);
  const [stats, setStats] = useState(null);
  const [zones, setZones] = useState([]);
  const [activeZone, setActiveZone] = useState('All');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      setError('');
      try {
        const [stationsRes, statsRes, zonesRes] = await Promise.all([
          stationApi.getAll(),
          dashboardApi.getStats(),
          stationApi.getZones(),
        ]);
        setStations(stationsRes.data.stations);
        setStats(statsRes.data.stats);
        setZones(zonesRes.data.zones);
      } catch (err) {
        setError(err.response?.data?.message || 'Could not load dashboard data. Is the API running?');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const filteredStations = useMemo(() => {
    return stations.filter((s) => {
      const matchesZone = activeZone === 'All' || s.zone === activeZone;
      const matchesSearch =
        !search ||
        s.name.toLowerCase().includes(search.toLowerCase()) ||
        s.stationCode.toLowerCase().includes(search.toLowerCase());
      return matchesZone && matchesSearch;
    });
  }, [stations, activeZone, search]);

  const cityCategory = stats?.avgAqi
    ? stats.avgAqi <= 50
      ? 'Good'
      : stats.avgAqi <= 100
      ? 'Moderate'
      : stats.avgAqi <= 150
      ? 'Poor'
      : stats.avgAqi <= 200
      ? 'Unhealthy'
      : stats.avgAqi <= 300
      ? 'Severe'
      : 'Hazardous'
    : 'Good';

  if (loading) {
    return (
      <div className="page">
        <Loader label="Fetching live station data" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="page">
        <div className="empty-state">
          <h3>Something went wrong</h3>
          <p>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">City-wide overview</span>
          <h1>Pollution monitoring dashboard</h1>
          <p className="subtitle">Live readings aggregated from {stats?.totalStations ?? 0} monitoring stations.</p>
        </div>
      </div>

      {/* Hero: city AQI + advice */}
      <div className="card" style={{ display: 'flex', gap: 28, alignItems: 'center', marginBottom: 24, flexWrap: 'wrap' }}>
        <AqiGauge aqi={stats?.avgAqi || 0} category={cityCategory} size={140} strokeWidth={11} />
        <div style={{ flex: 1, minWidth: 240 }}>
          <span className="eyebrow">City average AQI</span>
          <h2 style={{ fontSize: 22, marginTop: 4 }}>{AQI_ADVICE[cityCategory]}</h2>
          <p className="subtitle" style={{ marginTop: 10 }}>
            Worst zone right now:{' '}
            <strong style={{ color: 'var(--text-primary)' }}>
              {stats?.worstStation ? `${stats.worstStation.name} (AQI ${stats.worstStation.aqi})` : '—'}
            </strong>{' '}
            · Best zone:{' '}
            <strong style={{ color: 'var(--text-primary)' }}>
              {stats?.bestStation ? `${stats.bestStation.name} (AQI ${stats.bestStation.aqi})` : '—'}
            </strong>
          </p>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-4" style={{ marginBottom: 28 }}>
        <div className="card stat-card">
          <div className="stat-label">Active stations</div>
          <div className="stat-value">{stats?.activeStations ?? 0}</div>
          <div className="stat-sub">of {stats?.totalStations ?? 0} total</div>
        </div>
        <div className="card stat-card">
          <div className="stat-label">Active alerts</div>
          <div className="stat-value" style={{ color: stats?.activeAlerts ? 'var(--aqi-unhealthy)' : undefined }}>
            {stats?.activeAlerts ?? 0}
          </div>
          <div className="stat-sub">unacknowledged</div>
        </div>
        <div className="card stat-card">
          <div className="stat-label">Good / Moderate zones</div>
          <div className="stat-value">
            {(stats?.categoryBreakdown?.Good || 0) + (stats?.categoryBreakdown?.Moderate || 0)}
          </div>
          <div className="stat-sub">of {stats?.totalStations ?? 0} monitored</div>
        </div>
        <div className="card stat-card">
          <div className="stat-label">Registered users</div>
          <div className="stat-value">{stats?.totalUsers ?? 0}</div>
          <div className="stat-sub">citizens & admins</div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex-between" style={{ marginBottom: 16, flexWrap: 'wrap', gap: 12 }}>
        <div className="tag-select">
          <button
            className={`tag-option${activeZone === 'All' ? ' active' : ''}`}
            onClick={() => setActiveZone('All')}
          >
            All zones
          </button>
          {zones.map((z) => (
            <button
              key={z}
              className={`tag-option${activeZone === z ? ' active' : ''}`}
              onClick={() => setActiveZone(z)}
            >
              {z}
            </button>
          ))}
        </div>
        <input
          placeholder="Search stations…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            background: 'var(--surface)',
            border: '1px solid var(--border-strong)',
            borderRadius: 'var(--radius-sm)',
            padding: '9px 14px',
            fontSize: 13,
            minWidth: 220,
          }}
        />
      </div>

      {/* Station grid */}
      {filteredStations.length === 0 ? (
        <div className="empty-state">
          <h3>No stations match your filters</h3>
          <p>Try a different zone or clear your search.</p>
        </div>
      ) : (
        <div className="grid grid-cols-3">
          {filteredStations.map((station) => (
            <StationCard key={station._id} station={station} />
          ))}
        </div>
      )}
    </div>
  );
}
