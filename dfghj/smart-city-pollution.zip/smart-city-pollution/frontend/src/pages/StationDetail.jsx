import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Line,
  LineChart,
} from 'recharts';
import { stationApi, readingApi } from '../api';
import AqiGauge from '../components/AqiGauge';
import Loader from '../components/Loader';
import { badgeClass, formatDate, timeAgo, AQI_ADVICE } from '../utils/aqi';

const RANGE_OPTIONS = [
  { label: '24h', hoursBack: 24 },
  { label: '3 days', hoursBack: 72 },
  { label: '7 days', hoursBack: 168 },
];

export default function StationDetail() {
  const { id } = useParams();
  const [station, setStation] = useState(null);
  const [readings, setReadings] = useState([]);
  const [range, setRange] = useState(RANGE_OPTIONS[1]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      setError('');
      try {
        const [stationRes, readingsRes] = await Promise.all([
          stationApi.getOne(id),
          readingApi.getForStation(id, { limit: 300 }),
        ]);
        setStation(stationRes.data.station);
        setReadings(readingsRes.data.readings);
      } catch (err) {
        setError(err.response?.data?.message || 'Could not load station details.');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  if (loading) {
    return (
      <div className="page">
        <Loader label="Loading station history" />
      </div>
    );
  }

  if (error || !station) {
    return (
      <div className="page">
        <div className="empty-state">
          <h3>Station not found</h3>
          <p>{error || 'This station may have been removed.'}</p>
          <Link to="/" className="btn btn-secondary" style={{ marginTop: 12 }}>
            Back to dashboard
          </Link>
        </div>
      </div>
    );
  }

  const cutoff = Date.now() - range.hoursBack * 60 * 60 * 1000;
  const chartData = readings
    .filter((r) => new Date(r.recordedAt).getTime() >= cutoff)
    .map((r) => ({
      time: new Date(r.recordedAt).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit' }),
      aqi: r.aqi,
      pm25: r.pm25,
      pm10: r.pm10,
      no2: r.no2,
      so2: r.so2,
      o3: r.o3,
    }));

  const lr = station.latestReading || {};
  const hasData = typeof lr.aqi === 'number';

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">{station.zone}</span>
          <h1>{station.name}</h1>
          <p className="subtitle mono">
            {station.stationCode} · {station.city} · lat {station.location.lat}, lng {station.location.lng}
          </p>
        </div>
        <Link to="/" className="btn btn-secondary">
          ← All stations
        </Link>
      </div>

      <div className="card" style={{ display: 'flex', gap: 28, alignItems: 'center', marginBottom: 24, flexWrap: 'wrap' }}>
        <AqiGauge aqi={hasData ? lr.aqi : 0} category={lr.category || 'Good'} size={120} strokeWidth={10} />
        <div style={{ flex: 1, minWidth: 240 }}>
          <span className={badgeClass(lr.category)}>
            <span className="dot" />
            {lr.category || 'No data'}
          </span>
          <h2 style={{ fontSize: 18, marginTop: 10 }}>{hasData ? AQI_ADVICE[lr.category] : 'No readings recorded yet for this station.'}</h2>
          <p className="subtitle" style={{ marginTop: 8 }}>
            Last updated {hasData ? `${timeAgo(lr.recordedAt)} (${formatDate(lr.recordedAt)})` : '—'}
            {lr.dominantPollutant && (
              <>
                {' '}
                · Dominant pollutant: <strong className="mono">{lr.dominantPollutant.toUpperCase()}</strong>
              </>
            )}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-4" style={{ marginBottom: 28 }}>
        {[
          ['PM2.5', lr.pm25, 'µg/m³'],
          ['PM10', lr.pm10, 'µg/m³'],
          ['CO2', lr.co2, 'ppm'],
          ['NO2', lr.no2, 'ppb'],
          ['SO2', lr.so2, 'ppb'],
          ['O3', lr.o3, 'ppb'],
          ['Temperature', lr.temperature, '°C'],
          ['Humidity', lr.humidity, '%'],
        ].map(([label, value, unit]) => (
          <div className="card stat-card" key={label}>
            <div className="stat-label">{label}</div>
            <div className="stat-value" style={{ fontSize: 22 }}>
              {value !== undefined && value !== null ? value : '—'}
              {value !== undefined && value !== null && (
                <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 6 }}>{unit}</span>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="flex-between" style={{ marginBottom: 16 }}>
        <div className="section-title" style={{ marginBottom: 0 }}>
          AQI trend
        </div>
        <div className="tag-select">
          {RANGE_OPTIONS.map((opt) => (
            <button
              key={opt.label}
              className={`tag-option${range.label === opt.label ? ' active' : ''}`}
              onClick={() => setRange(opt)}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      <div className="card" style={{ marginBottom: 28 }}>
        {chartData.length === 0 ? (
          <div className="empty-state">
            <h3>No readings in this range</h3>
            <p>Try a wider time range.</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="aqiFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3fb0e8" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#3fb0e8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#6b7690' }} minTickGap={40} />
              <YAxis tick={{ fontSize: 11, fill: '#6b7690' }} />
              <Tooltip
                contentStyle={{ background: '#131b2e', border: '1px solid rgba(232,236,244,0.12)', borderRadius: 10, fontSize: 12 }}
              />
              <Area type="monotone" dataKey="aqi" stroke="#3fb0e8" fill="url(#aqiFill)" strokeWidth={2} name="AQI" />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="section-title">Pollutant breakdown</div>
      <div className="card">
        {chartData.length === 0 ? (
          <div className="empty-state">
            <h3>No data to chart</h3>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#6b7690' }} minTickGap={40} />
              <YAxis tick={{ fontSize: 11, fill: '#6b7690' }} />
              <Tooltip
                contentStyle={{ background: '#131b2e', border: '1px solid rgba(232,236,244,0.12)', borderRadius: 10, fontSize: 12 }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="pm25" stroke="#fb923c" strokeWidth={2} dot={false} name="PM2.5" />
              <Line type="monotone" dataKey="pm10" stroke="#fbbf24" strokeWidth={2} dot={false} name="PM10" />
              <Line type="monotone" dataKey="no2" stroke="#c05fee" strokeWidth={2} dot={false} name="NO2" />
              <Line type="monotone" dataKey="so2" stroke="#4ade80" strokeWidth={2} dot={false} name="SO2" />
              <Line type="monotone" dataKey="o3" stroke="#3fb0e8" strokeWidth={2} dot={false} name="O3" />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
