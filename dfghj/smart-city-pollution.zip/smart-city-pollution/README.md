# AirWatch — Smart City Pollution Monitoring System

A full-stack MERN application for monitoring real-time air quality across city
zones: citizens track live AQI on a dashboard and map, while admins manage
monitoring stations and log sensor readings that automatically compute AQI
and trigger alerts.

```
smart-city-pollution/
├── backend/     Express + MongoDB REST API
└── frontend/    React (Vite) single-page app
```

## Features

- **Public dashboard** — city-wide average AQI, per-zone filtering, search
- **Interactive map** — Leaflet map with color-coded AQI pins per station
- **Station detail pages** — live metrics + historical AQI/pollutant charts (Recharts)
- **Authentication** — JWT-based, roles: `citizen` and `admin`
- **Admin panel** — create/edit/delete stations, log new readings
- **Automatic AQI calculation** — EPA-style breakpoint formula (PM2.5, PM10, NO2, SO2, O3), dominant pollutant detection
- **Alerts** — auto-generated whenever a station's AQI reaches "Unhealthy" (150+) or worse

## Tech stack

- **Frontend:** React 18, Vite, React Router, Axios, Recharts, React-Leaflet
- **Backend:** Node.js, Express, MongoDB + Mongoose, JWT, bcrypt

---

## 1. Prerequisites

- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas connection string

## 2. Backend setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env and set MONGO_URI, JWT_SECRET, etc.
npm run seed     # optional but recommended: populates demo stations & readings
npm run dev      # starts the API on http://localhost:5000
```

Seeded demo accounts (created by `npm run seed`):

| Role    | Email                 | Password    |
|---------|-----------------------|-------------|
| Admin   | admin@smartcity.io    | Admin@123   |
| Citizen | citizen@smartcity.io  | Citizen@123 |

## 3. Frontend setup

```bash
cd frontend
npm install
cp .env.example .env
# edit .env if your API is not on http://localhost:5000/api
npm run dev      # starts the app on http://localhost:5173
```

Open `http://localhost:5173` in your browser. Sign in with the admin account
above to access the Admin Panel and log new readings.

## 4. API overview

| Method | Endpoint                              | Access        | Description                          |
|--------|----------------------------------------|---------------|---------------------------------------|
| POST   | `/api/auth/register`                  | Public        | Register a new citizen account        |
| POST   | `/api/auth/login`                     | Public        | Log in                                 |
| GET    | `/api/auth/me`                        | Private       | Get current user                       |
| GET    | `/api/stations`                       | Public        | List stations (supports `?zone=&status=&search=`) |
| GET    | `/api/stations/:id`                   | Public        | Get a single station                   |
| GET    | `/api/stations/meta/zones`            | Public        | List distinct zones                    |
| POST   | `/api/stations`                       | Admin         | Create a station                       |
| PUT    | `/api/stations/:id`                   | Admin         | Update a station                       |
| DELETE | `/api/stations/:id`                   | Admin         | Delete a station                       |
| GET    | `/api/readings/station/:stationId`    | Public        | Get reading history for a station      |
| POST   | `/api/readings`                       | Admin         | Log a new reading (auto-computes AQI)  |
| DELETE | `/api/readings/:id`                   | Admin         | Delete a reading                       |
| GET    | `/api/alerts`                         | Public        | List alerts (supports `?acknowledged=&severity=`) |
| PATCH  | `/api/alerts/:id/acknowledge`         | Admin         | Acknowledge an alert                   |
| GET    | `/api/dashboard/stats`                | Public        | City-wide aggregate stats              |

## 5. Deployment notes

- Set `CLIENT_URL` in the backend `.env` to your deployed frontend origin for CORS.
- Set `VITE_API_BASE_URL` in the frontend `.env` to your deployed API URL before running `npm run build`.
- Use a process manager (PM2, Docker, or your host's Node runtime) for the backend, and any static host (Vercel, Netlify, Nginx) for the built frontend (`npm run build` → `dist/`).
- Rotate `JWT_SECRET` to a long random value in production, and never commit `.env` files.
